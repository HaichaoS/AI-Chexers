from random_agent.Player import ExamplePlayer as Player
