from team_404.Player import ExamplePlayer as Player
