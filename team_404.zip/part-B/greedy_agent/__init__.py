from greedy_agent.Player import ExamplePlayer as Player
